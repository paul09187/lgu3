
<?php
require '../../../database/connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    session_start();
    $caseTitle = htmlspecialchars(strip_tags($_POST['case_title']));
    $caseType = htmlspecialchars(strip_tags($_POST['case_type']));
    $guardianName = htmlspecialchars(strip_tags($_POST['guardian_name']));
    $guardianContact = htmlspecialchars(strip_tags($_POST['guardian_contact']));
    $notes = htmlspecialchars(strip_tags($_POST['notes']));
    $createdBy = $_SESSION['user_id'];

    if (empty($caseTitle) || empty($caseType)) {
        echo json_encode(['success' => false, 'message' => 'Invalid input.']);
        exit;
    }

    try {
        $stmt = $conn->prepare("
            INSERT INTO cases (case_title, case_type, guardian_name, guardian_contact, notes, created_by)
            VALUES (:case_title, :case_type, :guardian_name, :guardian_contact, :notes, :created_by)
        ");
        $stmt->execute([
            'case_title' => $caseTitle,
            'case_type' => $caseType,
            'guardian_name' => $guardianName,
            'guardian_contact' => $guardianContact,
            'notes' => $notes,
            'created_by' => $createdBy,
        ]);

        echo json_encode(['success' => true, 'message' => 'Case added successfully.']);
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Database error.']);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $stmt = $conn->query("SELECT id, case_title, case_type, status, created_at FROM cases ORDER BY created_at DESC");
        $cases = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(['success' => true, 'cases' => $cases]);
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Database error.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
}
?>
