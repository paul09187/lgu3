
CREATE TABLE `cases` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `case_title` VARCHAR(255) NOT NULL,
    `case_type` ENUM('abuse', 'neglect', 'support', 'other') DEFAULT 'other',
    `guardian_name` VARCHAR(255) DEFAULT NULL,
    `guardian_contact` VARCHAR(50) DEFAULT NULL,
    `notes` TEXT DEFAULT NULL,
    `status` ENUM('open', 'in_progress', 'closed') DEFAULT 'open',
    `created_by` INT NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    FOREIGN KEY (`created_by`) REFERENCES `users`(`id`)
);
